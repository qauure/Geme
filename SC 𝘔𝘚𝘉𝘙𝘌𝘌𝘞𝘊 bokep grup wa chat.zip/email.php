<?php
$emailku = 'alfamididi@gmail.com'; // GANTI EMAIL KAMU DISINI
?>